<?php
    require_once("Student.php");
    
    // CRUD - Create, Read, Update, Delete
    class StudentManager
    {
        // Givan a name and email, create a new record in the database
        public function create($name, $email)
        {
            // Database type, Server, database, credentials: (user, password)
            $db = new PDO("mysql:host=localhost;dbname=madison_college", "root", "root");
            
            // Insert a new record
            $sql = "INSERT INTO students(`name`, `email`) VALUES (:name, :emailAddress)";
            
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            try
            {
                $query = $db->prepare($sql);
                $query->bindParam(":name", $name);
                $query->bindParam(":emailAddress", $email);
                $query->execute();
            }
            catch (Exception $ex)
            {
                echo "{$ex->getMessage()}<br/>";
            }
            
            return $db->lastInsertId(); // Returns the primary key of this INSERT
        }
        
        public function readAll()
        {
            // Database type, Server, database, credentials: (user, password)
            $db = new PDO("mysql:host=localhost;dbname=madison_college", "root", "root");
            
            // Read all records
            $sql = "SELECT * FROM students";
            
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            try
            {
                $query = $db->prepare($sql);
                $query->execute();
                
                $results = $query->fetchAll(PDO::FETCH_CLASS, "Student");
            }
            catch (Exception $ex)
            {
                echo "{$ex->getMessage()}<br/>";
            }
            
            //echo "<pre>";
            //print_r($results);
            //echo "</pre>";
            
            foreach ($results as $student)
            {
                echo $student;
            }
        }
        
        public function updateAll($id, $name, $email)
        {
            // Database type, Server, database, credentials: (user, password)
            $db = new PDO("mysql:host=localhost;dbname=madison_college", "root", "root");
            
            // Update a record
            $sql = "UPDATE students SET `name`=:name, `email`=:email WHERE `id`=:id";
            
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            try
            {
                $query = $db->prepare($sql);
                $query->bindParam(":id", $id);
                $query->bindParam(":name", $name);
                $query->bindParam(":email", $email);
                $query->execute();
                $rowsAffected = $query->rowCount();
            }
            catch (Exception $ex)
            {
                echo "{$ex->getMessage()}<br/>";
            }
            
            return $rowsAffected; // Returns the number of rows UPDATEd
        }
        
        // Given an id, delete the record in the database table
        public function delete($id)
        {
            // Database type, Server, database, credentials: (user, password)
            $db = new PDO("mysql:host=localhost;dbname=madison_college", "root", "root");
            
            // Delete a record
            $sql = "DELETE FROM students WHERE id=:id";
            
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            try
            {
                $query = $db->prepare($sql);
                $query->bindParam(":id", $id);
                $query->execute();
                $rowsAffected = $query->rowCount();
            }
            catch (Exception $ex)
            {
                echo "{$ex->getMessage()}<br/>";
            }
            
            return $rowsAffected; // Returns the number of rows DELETEd
        }
    }
?>
