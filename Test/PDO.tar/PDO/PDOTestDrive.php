<?php
    require_once("StudentManager.php");
    
    echo "Add a new student to the madison_college database<br/>";
    
    $manager = new StudentManager();
    
    //$manager->create('Buckaroo Banzai', 'buckaroo@banzai.com');
       
    //echo "Let's see if we can do a Little Bobby Tables on this<br/>";    
    //$manager->create("','');DROP TABLE students;--", "");
    
    //$id = $manager->create('Kevin the Minion', 'kevin@minionsAreUs.com');
    
    //echo "Inserted ID: $id into database<br/>";
    
    $id = $manager->create('Delete Me!', 'deleteme@madisoncollege.edu');
    
    echo "And the id is: $id<br/>";
    
    $rowsDeleted = $manager->delete($id);
    
    echo "Deleted number of rows: $rowsDeleted<br/>";
    
    // Delete a row that doesn't exist
    $rowsDeleted =$manager->delete(100);
    
    //echo "Deleted number of rows: $rowsDeleted<br/>";
    
    //$idBuckaroo = $manager->create('Buckaroo Banzai', 'buckaroo@banzai.com');
    
    // Update Buckaroo Banzai's email
    //$rowsUpdated = $manager->updateAll($idBuckaroo, 'Buckaroo Banzai', 'buckaroo@madisoncollege.edu');
    
    //echo "Updated number of rows: $rowsUpdated<br/>";
    
    $manager->readAll();
    
?>
