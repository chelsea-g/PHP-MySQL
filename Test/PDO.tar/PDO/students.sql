-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `madison_college`;
CREATE DATABASE `madison_college` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `madison_college`;

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `students` (`id`, `name`, `email`, `created`) VALUES
(4,	'Aaron Rodgers',	'arodgers@packers.com',	'2016-10-08 17:24:20'),
(6,	'Clay Mathews',	'cmathews@packers.com',	'2016-10-08 21:29:18'),
(55,	'\',\'\');DROP TABLE students;--',	'',	'2016-10-11 20:17:22'),
(56,	'Kevin the Minion',	'kevin@minionsAreUs.com',	'2016-10-11 20:21:50'),
(57,	'Kevin the Minion',	'kevin@minionsAreUs.com',	'2016-10-11 20:27:07'),
(61,	'Buckaroo Banzai',	'buckaroo@madisoncollege.edu',	'2016-10-11 20:51:15');

-- 2016-10-12 02:35:35
